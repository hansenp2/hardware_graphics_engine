#!/bin/bash -f
xv_path="/home/Xilinx/Vivado/2016.3"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
echo "xvlog -m64 --relax -prj tb_hello_world_vlog.prj"
ExecStep $xv_path/bin/xvlog -m64 --relax -prj tb_hello_world_vlog.prj 2>&1 | tee compile.log
