#!/bin/bash -f
xv_path="/home/Xilinx/Vivado/2016.3"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xelab -wto 9e3a4c3ccfca46e9888b65bac2053a78 -m64 --debug typical --relax --mt 8 -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip --snapshot tb_hello_world_behav xil_defaultlib.tb_hello_world xil_defaultlib.glbl -log elaborate.log
